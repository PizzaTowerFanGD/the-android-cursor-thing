// Minimal root build file for Android Gradle
plugins {
    id("com.android.application") version "8.3.0" apply false
    kotlin("android") version "1.9.0" apply false
}

// Keep root simple; module handles configs
